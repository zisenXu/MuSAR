
SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for s2_operation
-- ----------------------------
DROP TABLE IF EXISTS `s2_operation`;
CREATE TABLE `s2_operation`  (
  `command_id` bigint(0) NULL DEFAULT NULL,
  `user` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL,
  `remote_ip` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL,
  `tty` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL,
  `_raw` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL,
  `authority` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL,
  `command_keyword` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL,
  `parsed_args` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL,
  `input` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL,
  `output` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL,
  `target` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL,
  `command_type` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL,
  `is_sensitive` bigint(0) NULL DEFAULT NULL,
  `timestamp` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL,
  `host_ip` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL,
  `label` bigint(0) NULL DEFAULT NULL
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of s2_operation
-- ----------------------------
INSERT INTO `s2_operation` VALUES (4, 'ubuntu', '', '/dev/pts/3', './update_installer', 'user', 'bash', '\"[]\"', '\"update_installer\"', '\"stdout\"', '\"[]\"', 'Execution', 1, '2024-11-11 17:35:50', '192.168.9.104', 1);
INSERT INTO `s2_operation` VALUES (10, 'ubuntu', '', '/dev/pts/1', './update_installer', 'user', 'bash', '\"[]\"', '\"update_installer\"', '\"stdout\"', '\"[]\"', 'Execution', 1, '2024-11-11 17:35:50', '192.168.9.104', 1);
INSERT INTO `s2_operation` VALUES (11, 'ubuntu', '', '/dev/pts/1', 'ls', 'user', 'ls', '\"[]\"', '\"None\"', '\"stdout\"', '\"[]\"', '', 0, '2024-11-11 17:35:46', '192.168.9.104', 1);
INSERT INTO `s2_operation` VALUES (12, 'ubuntu', '', '/dev/pts/1', 'chmod +x update_installer', 'user', 'chmod', '\"[]\"', '\"update_installer\"', '\"stdout\"', '\"[]\"', 'Privilege_Escalation', 1, '2024-11-11 17:35:45', '192.168.9.104', 1);
INSERT INTO `s2_operation` VALUES (13, 'ubuntu', '', '/dev/pts/1', 'ls', 'user', 'ls', '\"[]\"', '\"None\"', '\"stdout\"', '\"[]\"', '', 0, '2024-11-11 17:35:40', '192.168.9.104', 1);
INSERT INTO `s2_operation` VALUES (14, 'ubuntu', '', '/dev/pts/1', 'cd 下载', 'user', 'cd', '\"[]\"', '\"None\"', '\"stdout\"', '\"[]\"', '', 0, '2024-11-11 17:35:38', '192.168.9.104', 1);
INSERT INTO `s2_operation` VALUES (15, 'ubuntu', '', '/dev/pts/1', 'cd', 'user', 'cd', '\"[]\"', '\"None\"', '\"stdout\"', '\"[]\"', '', 0, '2024-11-11 17:35:30', '192.168.9.104', 1);
INSERT INTO `s2_operation` VALUES (16, 'ubuntu', '', '/dev/pts/1', 'ls', 'user', 'ls', '\"[]\"', '\"None\"', '\"stdout\"', '\"[]\"', '', 0, '2024-11-11 17:35:30', '192.168.9.104', 1);
INSERT INTO `s2_operation` VALUES (17, 'ubuntu', '', '/dev/pts/1', 'ls', 'user', 'ls', '\"[]\"', '\"None\"', '\"stdout\"', '\"[]\"', '', 0, '2024-11-11 17:35:28', '192.168.9.104', 1);

SET FOREIGN_KEY_CHECKS = 1;
